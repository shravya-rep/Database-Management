1) 13 selfies are inside the selfies folder
2)starter_kml.kml---> Places visited are inside a folder 
		      Home is a seperate point
		      Convex hull includes all 13 points
		      D1,D2,D3,D4 are the 4 shortest distance places
3) The table creation and the queries are in Queries.txt
4) 13 places.png shows the screengrab of the 13 places in google earth
   convexhull_new.png shows the convex hull with transperant middle area
   convexhull_old.png shows the convex hull with shaded middle area
   4 closest places to home.png shows the 4 closest places to home
5) OL.html--> html file with OpenLayers code
6)Spirograph_code_java.txt has the java code for Spirograph point generation
  spiro.kml--> kml file for the spirogragh display around TT
  shapefile.zip--> shapefile using https://kmz2shp.com/ ( The website mentioned in the HW was asking me to pay up)
 TT_spiro_1.png shows the spirograph in Google Earth
 TT_spiro_2.png shows the spirograph in https://maps.equatorstudios.com/ 


