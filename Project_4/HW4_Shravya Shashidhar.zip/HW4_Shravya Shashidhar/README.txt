Attached all screenshots, For Q3 have two screenshots, one for coefficients and other for the design

Q1) 
MEDV= (-0.1084*CRIM)+(0.0458*ZN)+(2.7187*CHAS)+(-17.376)*(NOX)+(3.8016*RM)+(-1.4927*DIS)+(0.2996*RAD)+(-0.0118*TAX)+(-0.9465*PTRATIO)+(0.0093*B)+(-0.5226*LSTAT)+36.3411

There are 12 terms in the equation (11 variables in the equation and one constant)
This implies that the value will increase
1)as the number of rooms per dwelling increase( Makes sense as per the real estate standards)
2) if the tracts bounds river
3)accessibility to highways
4)residential land lots around
5)Proportion of blacks by town

The value is inversely related to
1)Crime rate 
2)Nitric oxide concentration
3)Distance to employment centers
4)Property tax rate
5) Pupil teacher ratio
6) status of the population

Independent of non retail bussiness acres and property built prior to 1940.

The constant value indicates the value is around 36000's if all the other variables are considered zero. It indicates the stand alone value of the property. 

Q2)
For Male
num_rings= (0.0577*sex)+(-0.4583*length)+(11.0751*diameter)+(10.7615*height)+(8.9754*whole_weight)+(-19.7869*shucked_weight)+(-10.5818*viscera_weight)+(8.7418*shell_weight)+3.8946

For Infants
num_rings= (-0.8249*sex)+(-0.4583*length)+(11.0751*diameter)+(10.7615*height)+(8.9754*whole_weight)+(-19.7869*shucked_weight)+(-10.5818*viscera_weight)+(8.7418*shell_weight)+3.8946

For Female
num_rings=(-0.4583*length)+(11.0751*diameter)+(10.7615*height)+(8.9754*whole_weight)+(-19.7869*shucked_weight)+(-10.5818*viscera_weight)+(8.7418*shell_weight)+3.8946

The num_rings is positively affected if
1) Diameter increases
2)height increases
3)Whole_weight increases
4)Shell weight increases

The num_rings can be reduced if
1) Length increases
2)shucked_weight increases
3)viscera_weight increases
4)If it is an infant 

If the variables are considered zero then the constant number of rings would be 3.8946
If the other variables are considered the same then males seem to have higher number of rings compared to females.


Q3) 
num_rings= (11.933*length)+(25.766*diameter)+(20.358*height)+2.836

Just by considering the 3 variables, the number of rings is highly dependant on the three(rather than being spread among the 8 variables previously). 
If the length, diameter and height is zeroed then the number of rings would be 2.836. 

Q4) Screenshot attached 






















